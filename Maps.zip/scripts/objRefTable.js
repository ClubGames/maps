const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Plugins.Text,
		C3.Plugins.yagames_adaptivetext,
		C3.Plugins.Mouse,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Plugins.yagames_adaptivetext.Acts.Destroy,
		C3.Plugins.Sprite.Acts.Spawn,
		C3.Plugins.yagames_adaptivetext.Acts.SetInstanceVar,
		C3.Plugins.System.Acts.SetVar,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.System.Cnds.ForEach,
		C3.Plugins.yagames_adaptivetext.Cnds.CompareInstanceVar,
		C3.Plugins.yagames_adaptivetext.Acts.SetPosToObject,
		C3.Plugins.Text.Cnds.IsBoolInstanceVarSet,
		C3.Plugins.Text.Acts.SetFontColor,
		C3.Plugins.System.Exps.rgba,
		C3.Plugins.yagames_adaptivetext.Acts.SetText,
		C3.Plugins.System.Cnds.CompareVar,
		C3.Plugins.yagames_adaptivetext.Acts.SetVisible,
		C3.Plugins.Sprite.Cnds.IsBoolInstanceVarSet,
		C3.Plugins.Mouse.Cnds.OnObjectClicked,
		C3.Plugins.System.Acts.SubVar,
		C3.Plugins.Sprite.Acts.SetSize,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.Text.Cnds.CompareInstanceVar,
		C3.Plugins.Text.Acts.SetBoolInstanceVar,
		C3.Plugins.Sprite.Acts.SetBoolInstanceVar,
		C3.Plugins.Sprite.Cnds.CompareFrame,
		C3.Plugins.Sprite.Acts.SetDefaultColor,
		C3.Plugins.System.Cnds.TriggerOnce,
		C3.Plugins.System.Acts.StopLoop,
		C3.Plugins.Sprite.Acts.SetAnimFrame,
		C3.Plugins.System.Exps.choose
	];
};
self.C3_JsPropNameTable = [
	{id: 0},
	{tr: 0},
	{button: 0},
	{Map: 0},
	{button_t: 0},
	{AdaptiveText: 0},
	{Mouse: 0},
	{Sprite: 0},
	{Sprite2: 0},
	{AdaptiveText2: 0},
	{Sprite3: 0},
	{totalMaps: 0},
	{currentmap: 0},
	{pickteam: 0},
	{shans: 0}
];

self.InstanceType = {
	button: class extends self.ISpriteInstance {},
	button_t: class extends self.ITextInstance {},
	AdaptiveText: class extends self.IWorldInstance {},
	Mouse: class extends self.IInstance {},
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	AdaptiveText2: class extends self.IWorldInstance {},
	Sprite3: class extends self.ISpriteInstance {}
}